﻿import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import PrivateRoute from './components/PrivateRoute';
import LoginPage from './pages/LoginPage';
import UploadPage from './pages/UploadPage';
import AdminPage from './pages/AdminPage';
import CompareResult from './pages/CompareResult';

export default function App() {
    return (
        <AuthProvider>
            <BrowserRouter>
                <Routes>
                    <Route path="/login" element={<LoginPage />} />

                    {/* Chỉ User vào được */}
                    <Route path="/upload" element={
                        <PrivateRoute requiredRole="User">
                            <UploadPage />
                        </PrivateRoute>
                    } />

                    {/* Trang kết quả so sánh */}
                    <Route path="/compare/:jobId" element={
                        <PrivateRoute requiredRole="User">
                            <CompareResult />
                        </PrivateRoute>
                    } />

                    {/* Chỉ Admin vào được */}
                    <Route path="/admin" element={
                        <PrivateRoute requiredRole="Admin">
                            <AdminPage />
                        </PrivateRoute>
                    } />

                    {/* Mặc định về login */}
                    <Route path="*" element={<Navigate to="/login" replace />} />
                </Routes>
            </BrowserRouter>
        </AuthProvider>
    );
}
