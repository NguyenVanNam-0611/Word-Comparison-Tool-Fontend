﻿import { useRef, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/api';

import Header from '../components/Header';
import Footer from '../components/Footer';

export default function UploadPage() {

    const navigate = useNavigate();

    const originalRef = useRef(null);
    const modifiedRef = useRef(null);

    const [file1, setFile1] = useState(null);
    const [file2, setFile2] = useState(null);

    const [loading, setLoading] = useState(false);

    const [errorPopup, setErrorPopup] = useState({
        show: false,
        message: ''
    });

    const [serverPopup, setServerPopup] = useState({
        show: false,
        type: 'error',
        title: '',
        message: ''
    });

    // BACK → LOGIN
    useEffect(() => {
        window.history.pushState(null, '', window.location.href);
        const handlePopState = () => navigate('/login');
        window.addEventListener('popstate', handlePopState);
        return () => window.removeEventListener('popstate', handlePopState);
    }, []);

    // FILE ICON
    const getFileIcon = (fileName) => {
        if (!fileName) return '/folder.png';
        const ext = fileName.split('.').pop().toLowerCase();
        if (ext === 'doc' || ext === 'docx') return '/word.png';
        if (ext === 'xls' || ext === 'xlsx') return '/excel.png';
        return '/folder.png';
    };

    // ERROR POPUP
    const openErrorPopup = (message) => {
        setErrorPopup({ show: true, message });
    };

    const handleSubmit = async () => {
        if (!file1 || !file2) {
            openErrorPopup('Bạn cần chọn đầy đủ cả file gốc và file chỉnh sửa trước khi so sánh.');
            return;
        }

        try {
            setLoading(true);

            const formData = new FormData();
            formData.append('file1', file1);
            formData.append('file2', file2);

            const { data } = await api.post(
                '/Upload/compare',
                formData,
                { headers: { 'Content-Type': 'multipart/form-data' } }
            );

            // Navigate sang trang kết quả với jobId
            navigate(`/compare/${data.job_id}`);

        } catch (err) {
            setServerPopup({
                show: true,
                type: 'error',
                title: 'Có lỗi xảy ra',
                message: err.response?.data?.message || 'Không kết nối được Compare Service'
            });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-green-100 to-green-200 flex flex-col">

            {/* HEADER */}
            <Header />

            {/* MAIN */}
            <main className="flex-1 p-6 lg:p-8 max-w-[1600px] mx-auto w-full flex flex-col gap-10">

                {/* GRID */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">

                    {/* ORIGINAL FILE */}
                    <div className="flex flex-col gap-3">
                        <h3 className="text-lg font-bold text-slate-800 px-1">Original File</h3>
                        <div
                            onClick={() => originalRef.current.click()}
                            className="cursor-pointer group flex flex-col items-center justify-center gap-5 bg-white/90 backdrop-blur-xl rounded-3xl border-2 border-dashed border-blue-300 hover:border-blue-500 min-h-[420px] p-6 transition"
                        >
                            <img
                                src={getFileIcon(file1?.name)}
                                alt="file icon"
                                className="w-20 h-20 object-contain"
                            />
                            <span className="font-semibold text-slate-600 text-lg text-center break-all">
                                {file1 ? file1.name : 'No file selected'}
                            </span>
                            <input
                                ref={originalRef}
                                type="file"
                                accept=".doc,.docx"
                                className="hidden"
                                onChange={(e) => setFile1(e.target.files[0])}
                            />
                        </div>
                    </div>

                    {/* MODIFIED FILE */}
                    <div className="flex flex-col gap-3">
                        <h3 className="text-lg font-bold text-slate-800 px-1">Modified File</h3>
                        <div
                            onClick={() => modifiedRef.current.click()}
                            className="cursor-pointer group flex flex-col items-center justify-center gap-5 bg-white/90 backdrop-blur-xl rounded-3xl border-2 border-dashed border-purple-300 hover:border-purple-500 min-h-[420px] p-6 transition"
                        >
                            <img
                                src={getFileIcon(file2?.name)}
                                alt="file icon"
                                className="w-20 h-20 object-contain"
                            />
                            <span className="font-semibold text-slate-600 text-lg text-center break-all">
                                {file2 ? file2.name : 'No file selected'}
                            </span>
                            <input
                                ref={modifiedRef}
                                type="file"
                                accept=".doc,.docx"
                                className="hidden"
                                onChange={(e) => setFile2(e.target.files[0])}
                            />
                        </div>
                    </div>

                </div>

                {/* BUTTON */}
                <div className="flex justify-center">
                    <button
                        type="button"
                        onClick={handleSubmit}
                        disabled={loading}
                        className="bg-green-600 hover:bg-green-700 text-white font-semibold px-8 py-3 rounded-full shadow-lg text-sm transition disabled:opacity-70"
                    >
                        {loading ? '⏳ Đang xử lý...' : 'So sánh tài liệu'}
                    </button>
                </div>

            </main>

            {/* FOOTER */}
            <Footer />

            {/* ERROR POPUP */}
            {errorPopup.show && (
                <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
                    <div className="bg-white rounded-2xl p-6 max-w-sm w-full mx-4 shadow-xl">
                        <p className="text-slate-700 text-center mb-4">{errorPopup.message}</p>
                        <button
                            onClick={() => setErrorPopup({ show: false, message: '' })}
                            className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2 rounded-full transition"
                        >
                            Đóng
                        </button>
                    </div>
                </div>
            )}

            {/* SERVER ERROR POPUP */}
            {serverPopup.show && (
                <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
                    <div className="bg-white rounded-2xl p-6 max-w-sm w-full mx-4 shadow-xl">
                        <h3 className="font-bold text-slate-800 text-center mb-2">{serverPopup.title}</h3>
                        <p className="text-slate-600 text-center mb-4">{serverPopup.message}</p>
                        <button
                            onClick={() => setServerPopup({ ...serverPopup, show: false })}
                            className="w-full bg-red-500 hover:bg-red-600 text-white font-semibold py-2 rounded-full transition"
                        >
                            Đóng
                        </button>
                    </div>
                </div>
            )}

        </div>
    );
}