import { WordDiff, MetaRow, EmptyHint, NumberingBadge } from '../WordDiff';

function NumberingPrefix({ numbering }) {
    if (!numbering?.label) return null;
    return <span className="numbering-prefix">{numbering.label}</span>;
}

function getInlineImages(node) {
    return (node?.children || []).filter(c => c?.type === 'image');
}

function getImgHash(img) {
    return img?.content?.sha256 || img?.image?.sha256 || img?.content?.hash || img?.image?.hash || '';
}

function getImgUrl(img) {
    return img?.image_url || img?.image?.image_url || img?.content?.image_url || '';
}

function inlineImagesChanged(leftNode, rightNode) {
    const leftImgs = getInlineImages(leftNode);
    const rightImgs = getInlineImages(rightNode);

    if (leftImgs.length !== rightImgs.length) return true;

    return leftImgs.some((img, idx) => {
        return getImgHash(img) !== getImgHash(rightImgs[idx]);
    });
}
function getChangedInlineImages(leftNode, rightNode, side) {
    const leftImgs = getInlineImages(leftNode);
    const rightImgs = getInlineImages(rightNode);

    if (side === 'left') {
        return leftImgs.filter((img, idx) => {
            const rightImg = rightImgs[idx];
            return !rightImg || getImgHash(img) !== getImgHash(rightImg);
        });
    }

    return rightImgs.filter((img, idx) => {
        const leftImg = leftImgs[idx];
        return !leftImg || getImgHash(img) !== getImgHash(leftImg);
    });
}
function InlineImages({ node, images }) {
    const finalImages = images || getInlineImages(node);

    if (!finalImages.length) return null;

    return (
        <div className="inline-images">
            {finalImages.map(img => {
                const url = getImgUrl(img);
                if (!url) return null;

                return (
                    <div key={img.uid} className="inline-img-box">
                        <img
                            src={url}
                            alt={img.content?.alt_text || 'inline image'}
                            style={{
                                maxWidth: '100%',
                                maxHeight: 480,
                                objectFit: 'contain',
                                display: 'block',
                                marginTop: 8,
                            }}
                        />
                    </div>
                );
            })}
        </div>
    );
}
function InlineImageCompare({ leftNode, rightNode, side }) {
    const changedImages = getChangedInlineImages(leftNode, rightNode, side);

    return (
        <div className="inline-image-only">
            <div className="inline-image-change-banner">
                🖼️ Chỉ thay đổi ảnh inline (nội dung đoạn văn không đổi)
            </div>
            <InlineImages images={changedImages} />
        </div>
    );
}

function TextBody({ wd, side, plainText, numbering, node, hideText }) {
    const hasSpans = Array.isArray(wd?.spans) && wd.spans.length > 0;

    return (
        <div className="txt">
            {!hideText && (
                <>
                    <NumberingPrefix numbering={numbering} />
                    {hasSpans
                        ? <WordDiff wd={wd} side={side} />
                        : plainText || <EmptyHint>(trống)</EmptyHint>
                    }
                </>
            )}

            <InlineImages node={node} />
        </div>
    );
}

export function TextChangeRow({ change }) {
    const kind = change.change_kind || 'replace';
    const wd = change.word_diff || {};
    const fc = change.format_changes || wd.format_changes || {};

    const leftNode = change.left?.node;
    const rightNode = change.right?.node;

    const leftNumbering = leftNode?.content?.numbering;
    const rightNumbering = rightNode?.content?.numbering;

    const leftPlainTxt =
        leftNode?.content?.text_display
        || leftNode?.content?.text
        || change.left?.preview_text
        || '';

    const rightPlainTxt =
        rightNode?.content?.text_display
        || rightNode?.content?.text
        || change.right?.preview_text
        || '';

    const textSame = leftPlainTxt.trim() === rightPlainTxt.trim();
    const numberingSame = JSON.stringify(leftNumbering || null) === JSON.stringify(rightNumbering || null);
    const imgChanged =
        leftNode && rightNode
            ? inlineImagesChanged(leftNode, rightNode)
            : false;

    const onlyInlineImageChanged =
        kind === 'replace'
        && leftNode
        && rightNode
        && textSame
        && numberingSame
        && imgChanged;

    if (kind === 'delete') {
        return (
            <div className={`change-row kind-${kind}`}>
                <div className="change-cell left">
                    <MetaRow change={change} side="left" />                 
                    <NumberingBadge formatChanges={fc} />
                    <TextBody
                        wd={wd}
                        side="left"
                        plainText={leftPlainTxt}
                        numbering={leftNumbering}
                        node={leftNode}
                    />
                </div>
                <div className="change-cell right">
                    <MetaRow change={change} side="right" />                   
                    <EmptyHint style={{ padding: 8 }}>(đã xóa)</EmptyHint>
                </div>
            </div>
        );
    }

    if (kind === 'insert') {
        return (
            <div className={`change-row kind-${kind}`}>
                <div className="change-cell left">
                    <MetaRow change={change} side="left" />                   
                    <EmptyHint style={{ padding: 8 }}>(chưa tồn tại)</EmptyHint>
                </div>
                <div className="change-cell right">
                    <MetaRow change={change} side="right" />                
                    <NumberingBadge formatChanges={fc} />
                    <TextBody
                        wd={wd}
                        side="right"
                        plainText={rightPlainTxt}
                        numbering={rightNumbering}
                        node={rightNode}
                    />
                </div>
            </div>
        );
    }

    return (
        <div className={`change-row kind-${kind}`}>
            <div className="change-cell left">
                <MetaRow change={change} side="left" />               
                <NumberingBadge formatChanges={fc} />
                {onlyInlineImageChanged ? (
                    <InlineImageCompare
                        leftNode={leftNode}
                        rightNode={rightNode}
                        side="left"
                    />
                ) : (
                    <TextBody
                        wd={wd}
                        side="left"
                        plainText={leftPlainTxt}
                        numbering={leftNumbering}
                        node={leftNode}
                    />
                )}
            </div>
            <div className="change-cell right">
                <MetaRow change={change} side="right" />             
                <NumberingBadge formatChanges={fc} />
                {onlyInlineImageChanged ? (
                    <InlineImageCompare
                        leftNode={leftNode}
                        rightNode={rightNode}
                        side="right"
                    />
                ) : (
                    <TextBody
                        wd={wd}
                        side="right"
                        plainText={rightPlainTxt}
                        numbering={rightNumbering}
                        node={rightNode}
                    />
                )}
            </div>
        </div>
    );
}