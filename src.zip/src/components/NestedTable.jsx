﻿// ─────────────────────────────────────────────────────────────
// NestedTable.jsx
// ─────────────────────────────────────────────────────────────
import { FullTable } from './FullTable';

export function NestedTable({ table, wrapClass = '' }) {
    if (!table) return <span className="empty-hint">(nested table trống)</span>;
    return (
        <div className={`nested-tbl-wrap ${wrapClass}`} style={{ marginTop: 4 }}>
            <FullTable tableData={table} label="neutral" />
        </div>
    );
}

export function NestedTableWithDiff({ nestedChange, side }) {
    if (!nestedChange) return null;
    const table = side === 'left' ? nestedChange.original : nestedChange.modified;
    const changes = nestedChange.changes || [];
    return (
        <div className="nested-tbl-wrap" style={{ marginTop: 4 }}>
            <FullTable
                tableData={table}
                label={side === 'left' ? 'before' : 'after'}
                tableChanges={changes}
            />
        </div>
    );
}