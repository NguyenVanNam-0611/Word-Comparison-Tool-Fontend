// components/table/TableChange.jsx
import { MetaRow, EmptyHint } from '../WordDiff';
import { getCellText, nodeToTableData } from '../../utils/diffHelpers';
import { CellContent, CellNode } from '../CellContent';
import { FullTable as LogicalFullTable } from '../FullTable';

function getTablePagePayload(sideObj, tableData) {
    const nodeContent = sideObj?.node?.content || {};
    const sideContent = sideObj?.content || {};
    const dataContent = tableData?.content || tableData || {};

    // Với table merge, page đúng nhất thường nằm trong node.content
    // hoặc full_table data. sideObj.page có thể chỉ là page của bảng đầu.
    const pageStart =
        nodeContent.page_start
        ?? dataContent.page_start
        ?? sideContent.page_start
        ?? sideObj?.page_start
        ?? nodeContent.page
        ?? dataContent.page
        ?? sideContent.page
        ?? sideObj?.page
        ?? null;

    const pageEnd =
        nodeContent.page_end
        ?? dataContent.page_end
        ?? sideContent.page_end
        ?? sideObj?.page_end
        ?? pageStart
        ?? null;

    const page =
        nodeContent.page
        ?? dataContent.page
        ?? sideContent.page
        ?? sideObj?.page
        ?? pageStart
        ?? null;

    return {
        page,
        page_start: pageStart,
        page_end: pageEnd,
    };
}

function buildTableMetaChange(change, leftTableData, rightTableData) {
    const leftPage = getTablePagePayload(change.left, leftTableData);
    const rightPage = getTablePagePayload(change.right, rightTableData);

    return {
        ...change,
        left: change.left
            ? {
                ...change.left,
                ...leftPage,
            }
            : change.left,
        right: change.right
            ? {
                ...change.right,
                ...rightPage,
            }
            : change.right,
    };
}

// ─────────────────────────────────────────────────────────────
// FullTable wrapper
// ─────────────────────────────────────────────────────────────
function FullTable({ tableData, label, tableChanges = [], structureChanged = false }) {
    if (Array.isArray(tableData?.cells)) {
        return (
            <LogicalFullTable
                tableData={tableData}
                label={label}
                tableChanges={tableChanges}
                structureChanged={structureChanged}
            />
        );
    }

    if (!tableData) return <div className="empty-hint" style={{ padding: 8 }}>(không có)</div>;

    const side = label === 'before' ? 'left' : 'right';
    const rows = tableData.rows || tableData.all_cells || [];
    const addedSet = new Set();
    const deletedSet = new Set();
    const modifiedSet = new Set();
    const cellChangeMap = {};
    const deletedColsPerRow = {};
    const addedColsPerRow = {};

    if (!structureChanged) {
        tableChanges.forEach(rc => {
            if (rc.type !== 'table_row_modified') return;
            const ri = rc.anchor_row ?? rc.row_index;
            (rc.cell_changes || []).forEach(cc => {
                const colKey = cc.anchor_col ?? cc.col_index;
                if (['table_cell_modified', 'table_cell_span_changed'].includes(cc.type)) {
                    if (!cellChangeMap[ri]) cellChangeMap[ri] = {};
                    cellChangeMap[ri][colKey] = cc;
                }
                if (cc.type === 'table_cell_deleted') {
                    if (!deletedColsPerRow[ri]) deletedColsPerRow[ri] = new Set();
                    deletedColsPerRow[ri].add(colKey);
                }
                if (cc.type === 'table_cell_added') {
                    if (!addedColsPerRow[ri]) addedColsPerRow[ri] = new Set();
                    addedColsPerRow[ri].add(colKey);
                }
            });
        });
    }

    return (
        <div className="tbl-wrap">
            <table className="doc-table">
                <tbody>
                    {rows.map((rowData, arrayIdx) => {
                        const cells = rowData.cells || rowData || [];
                        const ri = rowData.anchor_row ?? rowData.row_index ?? arrayIdx;
                        const rCls = addedSet.has(ri) ? 'row-added'
                            : deletedSet.has(ri) ? 'row-deleted'
                                : modifiedSet.has(ri) ? 'row-modified'
                                    : '';
                        let gridPos = 0;
                        const tds = cells
                            .filter(cell => {
                                if (!cell) return false;
                                const c = cell.anchor_col ?? cell.col_index ?? 0;
                                return c >= gridPos;
                            })
                            .map((cell, ci) => {
                                const colIdx = cell.anchor_col ?? cell.col_index ?? ci;
                                const cSpan = cell.col_span > 1 ? cell.col_span : undefined;
                                const rSpan = cell.row_span > 1 ? cell.row_span : undefined;
                                const cc = cellChangeMap[ri]?.[colIdx];
                               
                                const cellCls = cc
                                    ? 'cell-changed'
                                    : (label === 'before' && deletedColsPerRow[ri]?.has(colIdx)) ? 'cell-deleted'
                                        : (label === 'after' && addedColsPerRow[ri]?.has(colIdx)) ? 'cell-added'
                                            : '';
                                gridPos = colIdx + (cell.col_span > 1 ? Number(cell.col_span) : 1);
                                return (
                                    <td
                                        key={`${ri}_${colIdx}`}
                                        className={cellCls}
                                        colSpan={cSpan}
                                        rowSpan={rSpan}                                     
                                    >
                                        {cc
                                            ? <CellContent cellChange={cc} side={side} fallback={getCellText(cell)} cellNode={cell} />
                                            : <CellNode cellNode={cell} fallbackText={getCellText(cell)} />
                                        }
                                    </td>
                                );
                            });
                        return <tr key={ri} className={rCls}>{tds}</tr>;
                    })}
                </tbody>
            </table>
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// NestedTableLeft
// ─────────────────────────────────────────────────────────────
function NestedTableLeft({ rc }) {
    const outerCells = (rc.left_cells || []).filter(c => c && c.type !== 'cell_span_continuation');
    const nestedRows = rc.left_nested_rows || [];

    if (nestedRows.length === 0) {
        return (
            <div className="tbl-wrap">
                <table className="doc-table"><tbody>
                    <tr className="row-deleted">
                        {outerCells.map((c, i) => (
                            <td key={i} colSpan={c.col_span > 1 ? c.col_span : undefined}>
                                <CellNode cellNode={c} fallbackText={getCellText(c)} />
                            </td>
                        ))}
                    </tr>
                </tbody></table>
            </div>
        );
    }

    const labelCells = outerCells.slice(0, outerCells.length - 1);
    return (
        <div className="tbl-wrap">
            <table className="doc-table"><tbody>
                {nestedRows.map((nr, ni) => {
                    const nrCells = (nr.cells || []).filter(c => c && c.type !== 'cell_span_continuation');
                    return (
                        <tr key={ni} className="row-deleted">
                            {ni === 0 && labelCells.map((c, i) => (
                                <td key={`lbl-${i}`} rowSpan={nestedRows.length} colSpan={c.col_span > 1 ? c.col_span : undefined}>
                                    <CellNode cellNode={c} fallbackText={getCellText(c)} />
                                </td>
                            ))}
                            {nrCells.map((c, ci) => (
                                <td key={ci} colSpan={c.col_span > 1 ? c.col_span : undefined}>
                                    <CellNode cellNode={c} fallbackText={getCellText(c)} />
                                </td>
                            ))}
                        </tr>
                    );
                })}
            </tbody></table>
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// NestedTableRight
// ─────────────────────────────────────────────────────────────
function NestedTableRight({ rc }) {
    const outerCells = (rc.right_cells || []).filter(c => c && c.type !== 'cell_span_continuation');
    const nestedRows = rc.right_nested_rows || [];
    const labelCells = outerCells.slice(0, outerCells.length - 1);

    if (nestedRows.length === 0) {
        return (
            <div className="tbl-wrap">
                <table className="doc-table"><tbody>
                    <tr className="row-modified">
                        {outerCells.map((c, i) => (
                            <td key={i} colSpan={c.col_span > 1 ? c.col_span : undefined}>
                                <CellNode cellNode={c} fallbackText={getCellText(c)} />
                            </td>
                        ))}
                    </tr>
                </tbody></table>
            </div>
        );
    }

    return (
        <div className="tbl-wrap">
            <table className="doc-table"><tbody>
                {nestedRows.map((nr, ni) => {
                    const nrCells = (nr.cells || []).filter(c => c && c.type !== 'cell_span_continuation');
                    return (
                        <tr key={ni} className="row-modified">
                            {ni === 0 && labelCells.map((c, i) => (
                                <td key={`lbl-${i}`} rowSpan={nestedRows.length} colSpan={c.col_span > 1 ? c.col_span : undefined}>
                                    <CellNode cellNode={c} fallbackText={getCellText(c)} />
                                </td>
                            ))}
                            {nrCells.map((c, ci) => (
                                <td key={ci} colSpan={c.col_span > 1 ? c.col_span : undefined}>
                                    <CellNode cellNode={c} fallbackText={getCellText(c)} />
                                </td>
                            ))}
                        </tr>
                    );
                })}
            </tbody></table>
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// FlatRowsLeft / FlatRowsRight
// ─────────────────────────────────────────────────────────────
function FlatRowsLeft({ rc }) {
    const leftRows = rc.left_rows || [];
    const subDiffs = rc.sub_row_diffs || [];
    return (
        <div className="tbl-wrap">
            <table className="doc-table"><tbody>
                {leftRows.map((lr, li) => {
                    const sd = subDiffs[li];
                    const cells = (lr.cells || []).filter(c => c && c.type !== 'cell_span_continuation');
                    const ccMap = {};
                    ((sd && sd.cell_changes) || []).forEach(cc => {
                        ccMap[cc.anchor_col ?? cc.col_index] = cc;
                    });
                    return (
                        <tr key={li} className={sd?.has_changes ? 'row-deleted' : ''}>
                            {cells.map((c, ci) => {
                                const idx = c.anchor_col ?? c.col_index ?? ci;
                                const cc = ccMap[idx];
                                return (
                                    <td key={ci} className={cc ? 'cell-changed' : ''} colSpan={c.col_span > 1 ? c.col_span : undefined}>
                                        {cc
                                            ? <CellContent cellChange={cc} side="left" fallback={getCellText(c)} cellNode={cc.left_cell || c} />
                                            : <CellNode cellNode={c} fallbackText={getCellText(c)} />
                                        }
                                    </td>
                                );
                            })}
                        </tr>
                    );
                })}
            </tbody></table>
        </div>
    );
}

function FlatRowsRight({ rc }) {
    const rightRows = rc.right_rows || [];
    const subDiffs = rc.sub_row_diffs || [];
    return (
        <div className="tbl-wrap">
            <table className="doc-table"><tbody>
                {rightRows.map((rr, ri) => {
                    const sd = subDiffs[ri];
                    const cells = (rr.cells || []).filter(c => c && c.type !== 'cell_span_continuation');
                    const ccMap = {};
                    ((sd && sd.cell_changes) || []).forEach(cc => {
                        ccMap[cc.anchor_col ?? cc.col_index] = cc;
                    });
                    return (
                        <tr key={ri} className={sd?.has_changes ? 'row-modified' : ''}>
                            {cells.map((c, ci) => {
                                const idx = c.anchor_col ?? c.col_index ?? ci;
                                const cc = ccMap[idx];
                                return (
                                    <td key={ci} className={cc ? 'cell-changed' : ''} colSpan={c.col_span > 1 ? c.col_span : undefined}>
                                        {cc
                                            ? <CellContent cellChange={cc} side="right" fallback={getCellText(c)} cellNode={cc.right_cell || c} />
                                            : <CellNode cellNode={c} fallbackText={getCellText(c)} />
                                        }
                                    </td>
                                );
                            })}
                        </tr>
                    );
                })}
            </tbody></table>
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// SubRowDeleteBtn
// ─────────────────────────────────────────────────────────────
function SubRowDeleteBtn({ onClick }) {
    return (
        <button
            className="row-delete-btn"
            onClick={onClick}
            title="Xóa dòng này"
            aria-label="Xóa"
            style={{
                position: 'absolute',
                top: 4,
                right: 4
            }}
        >
            <img
                src="/delete_button_row.png"
                alt="Xóa dòng"
                className="delete-icon"
            />
        </button>
    );
}

// ─────────────────────────────────────────────────────────────
// RowModifiedView
// ─────────────────────────────────────────────────────────────
function RowModifiedView({ tableChanges, onDeleteSubRow }) {
    return (
        <div className="sub-rows-wrap">
            {tableChanges.map((rc, idx) => {
                const type = rc.type || '';
                let L = null, R = null;

                const leftPage = '';
                const rightPage = '';

                if (type === 'table_row_unflattened') {
                    const direction = rc.direction || 'nested_to_flat';
                    if (direction === 'nested_to_flat') {
                        L = (
                            <>
                                <div className="tbl-label" style={{ color: '#b45309' }}>≈ Dòng sửa (gốc — bảng lồng)</div>
                                <NestedTableLeft rc={rc} />
                                {(rc.unmatched_nested_rows || []).length > 0 && (
                                    <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 4 }}>
                                        +{rc.unmatched_nested_rows.length} dòng con không khớp
                                    </div>
                                )}
                            </>
                        );
                        R = (
                            <>
                                <div className="tbl-label" style={{ color: '#16a34a' }}>≈ Dòng sửa (mới — trải phẳng)</div>
                                <FlatRowsRight rc={rc} />
                                {(rc.unmatched_flat_rows || []).length > 0 && (
                                    <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 4 }}>
                                        +{rc.unmatched_flat_rows.length} dòng không khớp
                                    </div>
                                )}
                            </>
                        );
                    } else {
                        L = (
                            <>
                                <div className="tbl-label" style={{ color: '#b45309' }}>≈ Dòng sửa (gốc — nhiều dòng phẳng)</div>
                                <FlatRowsLeft rc={rc} />
                                {(rc.unmatched_flat_rows || []).length > 0 && (
                                    <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 4 }}>
                                        +{rc.unmatched_flat_rows.length} dòng không khớp
                                    </div>
                                )}
                            </>
                        );
                        R = (
                            <>
                                <div className="tbl-label" style={{ color: '#16a34a' }}>≈ Dòng sửa (mới — bảng lồng)</div>
                                <NestedTableRight rc={rc} />
                                {(rc.unmatched_nested_rows || []).length > 0 && (
                                    <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 4 }}>
                                        +{rc.unmatched_nested_rows.length} dòng con không khớp
                                    </div>
                                )}
                            </>
                        );
                    }
                }

                else if (type === 'table_row_modified') {
                    const lCells = rc.left_display_cells ?? rc.left_cells ?? [];
                    const rCells = rc.right_display_cells ?? rc.right_cells ?? [];
                    const ccMap = {};
                    const delCols = new Set();
                    const addCols = new Set();

                    (rc.cell_changes || []).forEach(cc => {
                        const key = cc.anchor_col ?? cc.col_index;
                        if (['table_cell_modified', 'table_cell_span_changed'].includes(cc.type))
                            ccMap[key] = cc;
                        else if (cc.type === 'table_cell_deleted') delCols.add(key);
                        else if (cc.type === 'table_cell_added') addCols.add(key);
                    });

                    const renderCells = (cells, side) =>
                        cells
                            .filter(c => c && c.type !== 'cell_span_continuation')
                            .map((c, i) => {
                                const ci = c.anchor_col ?? c.col_index ?? i;
                                const cc = ccMap[ci];
                                const chCls = cc
                                    ? 'cell-changed'
                                    : (side === 'left' && delCols.has(ci)) ? 'cell-deleted'
                                        : (side === 'right' && addCols.has(ci)) ? 'cell-added'
                                            : '';
                                const fallback = c.text_display ?? c.text ?? '';
                                const fullCell = cc ? (side === 'left' ? cc.left_cell : cc.right_cell) : null;                                                  

                                return (
                                    <td
                                        key={ci}
                                        className={`${chCls}${c.virtual_from_merge ? ' cell-virtual' : ''}`}
                                        colSpan={c.col_span > 1 ? c.col_span : undefined}
                                    >                                   

                                        {cc
                                            ? <CellContent cellChange={cc} side={side} fallback={fallback} cellNode={fullCell || c} />
                                            : <CellNode cellNode={c} fallbackText={fallback} />
                                        }
                                    </td>
                                );
                            });

                    L = (
                        <>
                            <div className="tbl-label" style={{ color: '#b45309' }}>≈ Dòng sửa (gốc){leftPage}</div>
                            <div className="tbl-wrap">
                                <table className="doc-table"><tbody>
                                    <tr>{renderCells(lCells, 'left')}</tr>
                                </tbody></table>
                            </div>
                        </>
                    );
                    R = (
                        <>
                            <div className="tbl-label" style={{ color: '#16a34a' }}>≈ Dòng sửa (mới){rightPage}</div>
                            <div className="tbl-wrap">
                                <table className="doc-table"><tbody>
                                    <tr>{renderCells(rCells, 'right')}</tr>
                                </tbody></table>
                            </div>
                        </>
                    );
                }

                else if (type === 'table_row_added') {
                    const cells = rc.right_display_cells ?? rc.right_cells ?? [];
                    R = (
                        <>
                            <div className="tbl-label" style={{ color: '#16a34a' }}>+ Dòng mới{rightPage}</div>
                            <div className="tbl-wrap">
                                <table className="doc-table"><tbody>
                                    <tr className="row-added">
                                        {cells
                                            .filter(c => c && c.type !== 'cell_span_continuation')
                                            .map((c, i) => (
                                                <td key={i} colSpan={c.col_span > 1 ? c.col_span : undefined}>
                                                    <CellNode cellNode={c} fallbackText="" />
                                                </td>
                                            ))
                                        }
                                    </tr>
                                </tbody></table>
                            </div>
                        </>
                    );
                }

                else if (type === 'table_row_deleted') {
                    const cells = rc.left_display_cells ?? rc.left_cells ?? [];
                    L = (
                        <>
                            <div className="tbl-label" style={{ color: '#dc2626' }}>- Dòng xóa{leftPage}</div>
                            <div className="tbl-wrap">
                                <table className="doc-table"><tbody>
                                    <tr className="row-deleted">
                                        {cells
                                            .filter(c => c && c.type !== 'cell_span_continuation')
                                            .map((c, i) => (
                                                <td key={i} colSpan={c.col_span > 1 ? c.col_span : undefined}>
                                                    <CellNode cellNode={c} fallbackText="" />
                                                </td>
                                            ))
                                        }
                                    </tr>
                                </tbody></table>
                            </div>
                        </>
                    );
                }

                else if (type === 'table_row_merged') {
                    const mergedFrom = rc.merged_from_rows || [];
                    const rCells = rc.right_display_cells ?? rc.right_cells ?? [];
                    L = (
                        <>
                            <div className="tbl-label" style={{ color: '#b45309' }}>
                                ⊕ Gộp ({rc.merged_from_count || mergedFrom.length} → 1)
                            </div>
                            <div className="tbl-wrap">
                                <table className="doc-table"><tbody>
                                    {mergedFrom.map((r, ri) => (
                                        <tr key={ri} className="row-deleted">
                                            {(r.cells || []).map((c, ci) => (
                                                <td key={ci} colSpan={c?.col_span > 1 ? c.col_span : undefined}>
                                                    <CellNode cellNode={c} fallbackText="" />
                                                </td>
                                            ))}
                                        </tr>
                                    ))}
                                </tbody></table>
                            </div>
                        </>
                    );
                    R = (
                        <>
                            <div className="tbl-label" style={{ color: '#16a34a' }}>⊕ Sau khi gộp</div>
                            <div className="tbl-wrap">
                                <table className="doc-table"><tbody>
                                    <tr className="row-modified">
                                        {rCells
                                            .filter(c => c && c.type !== 'cell_span_continuation')
                                            .map((c, i) => {
                                                const ci = c.anchor_col ?? c.col_index ?? i;
                                                const cc = (rc.cell_changes || []).find(x => (x.anchor_col ?? x.col_index) === ci);
                                                return (
                                                    <td
                                                        key={i}
                                                        className={c.virtual_from_merge ? 'cell-virtual' : ''}
                                                        colSpan={c.col_span > 1 ? c.col_span : undefined}
                                                    >
                                                        {cc
                                                            ? <CellContent cellChange={cc} side="right" fallback={getCellText(c)} cellNode={c} />
                                                            : <CellNode cellNode={c} fallbackText="" />
                                                        }
                                                    </td>
                                                );
                                            })
                                        }
                                    </tr>
                                </tbody></table>
                            </div>
                        </>
                    );
                }

                return (
                    <div key={idx} className="sub-row" style={{ position: 'relative' }}>
                        <div className="sub-cell sub-left">{L}</div>
                        <div className="sub-cell">{R}</div>
                        {onDeleteSubRow && (
                            <SubRowDeleteBtn onClick={() => onDeleteSubRow(idx)} />
                        )}
                    </div>
                );
            })}
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// TableChange — export chính
// ─────────────────────────────────────────────────────────────
export function TableChange({ change, onDeleteSubRow }) {
    const analysis = change.table_analysis || {};
    const tableChanges = change.table_changes || analysis.table_changes || [];
    const renderMode = analysis.render_mode || 'full_table';
    const kind = change.change_kind || 'replace';
    const structChanged = !!analysis.structure_changed;

    const leftTableData = analysis.full_table_original ?? nodeToTableData(change.left?.node);
    const rightTableData = analysis.full_table_modified ?? nodeToTableData(change.right?.node);

    const isDeleted = kind === 'delete' || renderMode === 'table_deleted' || change.type === 'table_deleted';
    const isInserted = kind === 'insert' || renderMode === 'table_added' || change.type === 'table_inserted';
    const isSubRows = !isDeleted && !isInserted && renderMode === 'row_modified';

    const metaChange = buildTableMetaChange(
        change,
        leftTableData,
        rightTableData
    );

    const metaBar = (
        <div className="meta-bar table-meta-bar">
            <div className="table-meta-left">
                <MetaRow change={metaChange} side="left" />
            </div>
            <div className="table-meta-right">
                <MetaRow change={metaChange} side="right" />
            </div>
        </div>
    );

    if (isSubRows) {
        return (
            <div className={`change-row kind-${kind}`} style={{ display: 'block' }}>
                {metaBar}
                <RowModifiedView
                    tableChanges={tableChanges}
                    onDeleteSubRow={onDeleteSubRow}
                />
            </div>
        );
    }

    if (isDeleted) {
        return (
            <div className={`change-row kind-${kind}`} style={{ display: 'block' }}>
                {metaBar}
                <div style={{ display: 'flex', alignItems: 'stretch' }}>
                    <div className="change-cell left">
                        <div className="tbl-side-wrap">
                            <FullTable tableData={leftTableData ?? rightTableData} label="before" />
                        </div>
                    </div>
                    <div className="change-cell right">
                        <EmptyHint style={{ padding: 10 }}>(đã xóa)</EmptyHint>
                    </div>
                </div>
            </div>
        );
    }

    if (isInserted) {
        return (
            <div className={`change-row kind-${kind}`} style={{ display: 'block' }}>
                {metaBar}
                <div style={{ display: 'flex', alignItems: 'stretch' }}>
                    <div className="change-cell left">
                        <EmptyHint style={{ padding: 10 }}>(chưa tồn tại)</EmptyHint>
                    </div>
                    <div className="change-cell right">
                        <div className="tbl-side-wrap">
                            <FullTable tableData={rightTableData ?? leftTableData} label="after" />
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    if (renderMode === 'full_table' || renderMode === 'table_layout_changed') {
        return (
            <div className={`change-row kind-${kind}`} style={{ display: 'block' }}>
                {metaBar}
                <div style={{ display: 'flex', alignItems: 'stretch' }}>
                    <div className="change-cell left">
                        <div className="tbl-side-wrap">
                            <FullTable tableData={leftTableData} label="before" tableChanges={tableChanges} structureChanged={structChanged} />
                        </div>
                    </div>
                    <div className="change-cell right">
                        <div className="tbl-side-wrap">
                            <FullTable tableData={rightTableData} label="after" tableChanges={tableChanges} structureChanged={structChanged} />
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    if (renderMode === 'row_added') {
        const headerRow = analysis.header_row;
        const addedRows = analysis.added_rows || [];
        return (
            <div className={`change-row kind-${kind}`} style={{ display: 'block' }}>
                {metaBar}
                <div style={{ display: 'flex', alignItems: 'stretch' }}>
                    <div className="change-cell left">
                        <EmptyHint style={{ padding: 8 }}>Không có dòng mới ở bên gốc.</EmptyHint>
                    </div>
                    <div className="change-cell right">
                        <div className="tbl-side-wrap">
                            <div className="tbl-label" style={{ color: '#16a34a' }}>▼ Dòng được thêm</div>
                            <div className="tbl-wrap">
                                <table className="doc-table"><tbody>
                                    {headerRow && (
                                        <tr>
                                            {(headerRow.cells || []).map((c, i) => (
                                                <th key={i}>{getCellText(c)}</th>
                                            ))}
                                        </tr>
                                    )}
                                    {addedRows.map((r, ri) => {
                                        const cells = r.right_display_cells ?? r.right_cells ?? r.right_row?.cells ?? [];
                                        return (
                                            <tr key={ri} className="row-added">
                                                {cells
                                                    .filter(c => c && c.type !== 'cell_span_continuation')
                                                    .map((c, ci) => (
                                                        <td
                                                            key={ci}
                                                            className={c.virtual_from_merge ? 'cell-virtual' : ''}
                                                            colSpan={c.col_span > 1 ? c.col_span : undefined}
                                                        >
                                                            <CellNode cellNode={c} fallbackText="" />
                                                        </td>
                                                    ))
                                                }
                                            </tr>
                                        );
                                    })}
                                </tbody></table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className={`change-row kind-${kind}`} style={{ display: 'block' }}>
            {metaBar}
            <div style={{ display: 'flex' }}>
                <div className="change-cell left" />
                <div className="change-cell right" />
            </div>
        </div>
    );
}