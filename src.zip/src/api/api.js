﻿import axios from 'axios';

const api = axios.create({
    baseURL: '/api'
});

// REQUEST - Gắn token vào header
api.interceptors.request.use(config => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// RESPONSE - Xử lý lỗi
api.interceptors.response.use(
    response => response,
    error => {
        const isLoginRequest = error.config?.url?.includes('/auth/login');

        // Chỉ redirect về login nếu KHÔNG phải request login
        if (error.response?.status === 401 && !isLoginRequest) {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            window.location.href = '/login';
        }

        return Promise.reject(error);
    }
);

export default api;